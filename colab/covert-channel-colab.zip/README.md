# Closing the Wrong Attribute — v2

**Co-tenant information flow in agentic evaluation infrastructure.**
AI Incident Response Sprint (Apart Research + CeSIA), September 2026 — Track 1, containment.

This is a rebuild, not an edit. A five-seat review of v1 returned **unanimous major revision**,
with the methodology seat at reject, and the findings were severe enough that patching would have
left the paper's shape wrong. `../project/` is retained unchanged as the record of what v1 claimed.

---

## What the review found, and what changed

Five reviewers committed independently, none able to see another's report. Every finding below was
re-verified against the repository before being acted on.

| Finding | Seat | Verified | Response in v2 |
|---|---|---|---|
| The 96.8% headline is `8192/8467` — a ratio of constants we chose, not a measurement | R1, R2, DA | yes | **Capacity is now measured**, not asserted — `src/capacity.py` |
| `order` declares `log2(n!)` and stores `8.0`; at `MAX_ENTRIES=256` that formula gives **1684** | R2 | yes, exactly | Nominal bounds demoted; the measured rate for `order` is **0** |
| Cost table contradicted its own artifact: false caption, unsourced sd, 4 wrong cells, 3 of 16 budgets reported | DA | yes | Table rebuilt from `cost.json`; both axes reported |
| `dirname` closure shows `mkdir_ok = 0.00` — omitted from the paper while reported for other rungs | DA | yes | Reported; "free" is now qualified to the task-success axis |
| **Generation declared as the unit of independence but never implemented** — Δ computed over pooled episodes | R1 | yes | `generation_cells()` + `cluster_permutation_p()` |
| Covert-channel taxonomy misapplied; the classical definition is policy-relative | R2 | argument accepted | Reframed — see below |
| AIS-11 amendment claimed four times, absent from the PDF | Journal-Fit | yes | Appendix, in the paper |
| Abstract 372 words against a hard 150-word venue limit | Journal-Fit | yes | Rewritten to 144 |
| No artifact URL anywhere in the paper | Journal-Fit | yes | Added |
| "Enumeration as the intervention" ignores HAZOP / FMEA / STAMP | R3 | yes, `ref.bib` had zero safety-engineering entries | Cited and positioned |

### The two changes that matter most

**Capacity is measured.** `src/capacity.py` has a sender encode a uniformly random payload into
one attribute using only ordinary substrate primitives, and a receiver decode it through
`list_dir`, `stat` and `read_file`. It reports the largest payload recovered **exactly on every
trial** — an achievable rate, established by exhibiting a working code, and falsifiable in the
direction that matters: if the channel does not work, the number is zero.

It already found something no constant could have. The `order` channel measures **0 bits**,
because `list_dir` returns entries alphabetically sorted, so the sender's creation order is never
observable — *even with the channel fully open*. v1 asserted 8 bits; the reviewer's corrected
arithmetic implied 1684; the substrate says neither. That single result is the argument for
measuring.

**Generation is now genuinely the unit of independence.** v1 declared it in the pre-registration
and computed Δ over pooled episodes in `verify.py` and `scorecard.py`. With two agents per
generation that doubles the apparent sample size and treats two agents sharing one substrate as
independent — when the whole hypothesis is that one changes the other's environment. Measured on a
plausible 7-vs-3 outcome:

    pseudo-replicated (episodes, n=20):  p = 0.0256   crosses 0.05
    correct (generations, n=10):         p = 0.1789   does not

The apparatus would have reported a significant effect that is not there. This was not inherited
from v1's authors alone: Amendment 9 corrected the *estimator family* (z-test → exact) while
leaving the *unit* wrong, and its own justification asserted "n is 10 per arm" while the code
computed 18.

### The reframe

v1 argued that the incident was a covert channel authorization controls are *constitutively*
unable to see. The domain seat's objection is that the classical definition is **relative to a
stated policy** — a covert channel violates the policy a reference monitor is enforcing — and on
v1's own account there was no policy to violate: same tenant, all legitimately authorized, every
audit check passing.

That is not a weaker finding, it is a sharper one. What the record describes is an **unenforced
non-interference requirement**: the architectural intent "these agents must not communicate" was
never expressed to any enforcement mechanism. Per-agent namespaces would have stopped it as an
ordinary overt flow — an option v1 never considered because its framing excluded it.

---

## Layout

```
src/          substrate, closure ladder, task family, and capacity.py (measured rates)
runner/       episode loop, provider adapters, difficulty calibration
detect/       content monitor and SRM monitor
analyze/      measures (generation-level inference), claim verifier, scorecard
paper/        main.tex and the AIS-11 amendment
docs/         incident timeline, novelty positioning, pre-registration
results/      capacity.json, cost.json, fixtures
```

## Reproducing

```bash
python check.py                 # six suites: no GPU, no network, no keys
python src/capacity.py          # measure achievable rates per rung
```

`check.py` recomputes every `CLAIM` marker in the paper from source and exits non-zero if the
paper and the artifacts disagree. **Its limit is now documented rather than assumed:** consistency
checking cannot detect an inappropriate estimator or a constant that contradicts its own formula.
Both defects were live in v1 and passed every check. Three of the review's most serious findings
were of exactly that kind, which is why v2 measures rather than declares wherever it can.

## Status

The inheritance advantage Δ remains **unmeasured**. That is stated plainly and is not the paper's
headline in v2. What is complete: the measured capacity table, the corrected cost curve on both
axes, the control-gap analysis, the six-clause amendment, and the released instrument.
